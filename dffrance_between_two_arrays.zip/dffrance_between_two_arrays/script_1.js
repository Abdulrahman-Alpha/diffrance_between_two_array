// diffrance function for two arrays
function difarray(arr1,arr2)
{
 var newarray = arr1.concat(arr2); // to merge two arrays
 return newarray.filter(function(value, index, array) 
     {
    if (array.slice(index+1).indexOf(value) === -1 && array.slice(0, index).indexOf(value) === -1 )
     {
                return value;
     }
     }); // to filter repeated items  
}
console.log(difarray([1,2,5],[1,2,3,4,5,6]));    
//-------------------------------
// developed by abdulrahman(alpha).